import React from 'react';
import { Link } from 'react-router-dom';
import './LeftSidebar.css';

const LeftSidebar = () => {
  return (
    <div className="left-sidebar">
      <ul className="sidebar-menu">
        <li className="sidebar-item"><Link to="/home">🏠 Home</Link></li>
        <li className="sidebar-item"><Link to="/login">🔑 Login</Link></li>
        <li className="sidebar-item"><Link to="/signup">📝 Sign Up</Link></li>
        <li className="sidebar-item"><Link to="/add-tweet">📝Add Tweet</Link></li>
        <li className="sidebar-item"><Link to="/settings">⚙️ Settings</Link></li>
        <li className="sidebar-item"><Link to="/security">🔒 Security</Link></li>
        <li className="sidebar-item"><Link to="/privacy">🔏 Privacy</Link></li>
      </ul>
    </div>
  );
};

export default LeftSidebar;
