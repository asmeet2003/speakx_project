import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="navbar-container">
        <h1 className="navbar-logo">Twitter Clone</h1>
      </div>
      <ul className="navbar-menu">
        <li className="navbar-item"><Link to="/home">Home</Link></li>
        <li className="navbar-item"><Link to="/add-tweet">Add Tweet</Link></li>
        <li className="navbar-item"><Link to="/login">Login</Link></li>
        <li className="navbar-item"><Link to="/signup">Sign Up</Link></li>
        <li className="navbar-item"><Link to="/settings">Settings</Link></li>
        <li className="navbar-item"><Link to="/security">Security</Link></li>
        <li className="navbar-item"><Link to="/privacy">Privacy</Link></li>
      </ul>
    </nav>
  );
};

export default Navbar;
