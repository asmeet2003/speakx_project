import React, { useState } from 'react';
import './Privacy.css';

const Privacy = () => {
  const [profileVisibility, setProfileVisibility] = useState('public');
  const [adPreferences, setAdPreferences] = useState(false);
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
  
    console.log('Profile Visibility:', profileVisibility);
    console.log('Ad Preferences:', adPreferences);

 
    setMessage('Your data is saved');
    setTimeout(() => setMessage(''), 2000); 
  };

  return (
    <div className="privacy-container">
      <h2>Privacy and Safety</h2>
      <form onSubmit={handleSubmit}>
        <div className="input-group">
          <label htmlFor="profileVisibility">Profile Visibility</label>
          <select
            id="profileVisibility"
            value={profileVisibility}
            onChange={(e) => setProfileVisibility(e.target.value)}
          >
            <option value="public">Public</option>
            <option value="private">Private</option>
          </select>
        </div>
        <div className="input-group">
          <label htmlFor="adPreferences">Ad Preferences</label>
          <input
            type="checkbox"
            id="adPreferences"
            checked={adPreferences}
            onChange={(e) => setAdPreferences(e.target.checked)}
          />
        </div>
        <button type="submit">Save</button>
      </form>
      {message && <div className="success-message">{message}</div>}
    </div>
  );
};

export default Privacy;
