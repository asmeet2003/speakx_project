import React, { useState } from 'react';
import './AddTweet.css';

const AddTweet = () => {
  const [tweet, setTweet] = useState('');
  const [image, setImage] = useState(null);
  const [tweets, setTweets] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (tweet.trim() || image) {
      const newTweet = {
        content: tweet,
        image: image ? URL.createObjectURL(image) : null
      };
      setTweets([...tweets, newTweet]);
      setTweet('');
      setImage(null);
    }
  };

  const handleImageChange = (e) => {
    setImage(e.target.files[0]);
  };

  return (
    <div className="add-tweet-container">
      <h2>Add a Tweet</h2>
      <form onSubmit={handleSubmit}>
        <textarea
          value={tweet}
          onChange={(e) => setTweet(e.target.value)}
          placeholder="What's happening?"
          required
        ></textarea>
        <input type="file" accept="image/*" onChange={handleImageChange} />
        <button type="submit">Tweet</button>
      </form>
      <div className="tweet-list">
        {tweets.map((tweet, index) => (
          <div key={index} className="tweet">
            <p>{tweet.content}</p>
            {tweet.image && <img src={tweet.image} alt="Tweet" className="tweet-image" />}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AddTweet;
