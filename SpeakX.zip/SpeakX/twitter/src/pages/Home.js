import React from 'react';
import './Home.css';
import user1Image from '../assets/user1.jpeg';
import user2Image from '../assets/user1.jpeg';
import user3Image from '../assets/user1.jpeg';

const Home = () => {
  
  const tweets = [
    { id: 1, username: 'Asmeet Arora', content: 'This is the first tweet', imageUrl: user1Image },
    { id: 2, username: 'Anand69', content: 'This is the second tweet', imageUrl: user2Image },
    { id: 3, username: 'Manav Joshi', content: 'This is the third tweet', imageUrl: user3Image },
  ];

  return (
    <div className="home-container">
      <div className="feed">
        {tweets.map(tweet => (
          <div key={tweet.id} className="tweet">
            <div className="tweet-header">
              <img src={tweet.imageUrl} alt={`${tweet.username}'s profile`} className="profile-pic" />
              <h3>@{tweet.username}</h3>
            </div>
            <p>{tweet.content}</p>
          </div>
        ))}
      </div>
      <div className="sidebar">
        <h3>Trending</h3>
        
        <p>#ReactJS</p>
        <p>#JavaScript</p>
        <p>#WebDevelopment</p>
      </div>
    </div>
  );
};

export default Home;
