import React, { useState } from 'react';
import './Security.css';

const Security = () => {
  const [password, setPassword] = useState('');
  const [twoFactorAuth, setTwoFactorAuth] = useState(false);
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
     console.log('Password:', password);
    console.log('Two-Factor Authentication:', twoFactorAuth);

     setMessage('Your data is saved');
    setTimeout(() => setMessage(''), 2000);  
  };

  return (
    <div className="security-container">
      <h2>Security and Account Access</h2>
      <form onSubmit={handleSubmit}>
        <div className="input-group">
          <label htmlFor="password">Change Password</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <div className="input-group">
          <label htmlFor="twoFactorAuth">Two-Factor Authentication</label>
          <input
            type="checkbox"
            id="twoFactorAuth"
            checked={twoFactorAuth}
            onChange={(e) => setTwoFactorAuth(e.target.checked)}
          />
        </div>
        <button type="submit">Save</button>
      </form>
      {message && <div className="success-message">{message}</div>}
    </div>
  );
};

export default Security;
