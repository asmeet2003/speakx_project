import React, { useState } from 'react';
import './Settings.css';

const Settings = () => {
  const [activeSection, setActiveSection] = useState('account');

  
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
     console.log('Name:', name);
    console.log('Email:', email);
    console.log('Password:', password);
  };

  const renderSection = () => {
    switch (activeSection) {
      case 'account':
        return (
          <div>
            <h3>Your Account</h3>
            <form onSubmit={handleSubmit}>
              <div className="input-group">
                <label htmlFor="name">Name</label>
                <input
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              <div className="input-group">
                <label htmlFor="email">Email</label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="input-group">
                <label htmlFor="password">Password</label>
                <input
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              <button type="submit">Save</button>
            </form>
          </div>
        );
      case 'monetization':
        return <h3>Monetization</h3>;
      case 'premium':
        return <h3>Premium</h3>;
      case 'subscriptions':
        return <h3>Creator Subscriptions</h3>;
      case 'security':
        return <h3>Security and account access</h3>;
      case 'privacy':
        return <h3>Privacy and safety</h3>;
      case 'notifications':
        return <h3>Notifications</h3>;
      case 'accessibility':
        return <h3>Accessibility, display, and languages</h3>;
      case 'resources':
        return <h3>Additional resources</h3>;
      case 'help':
        return <h3>Help Center</h3>;
      default:
        return null;
    }
  };

  return (
    <div className="settings-container">
      <h2>Settings</h2>
      <div className="settings-menu">
        <ul>
          <li onClick={() => setActiveSection('account')}>Your account</li>
          <li onClick={() => setActiveSection('monetization')}>Monetization</li>
          <li onClick={() => setActiveSection('premium')}>Premium</li>
          <li onClick={() => setActiveSection('subscriptions')}>Creator Subscriptions</li>
          <li onClick={() => setActiveSection('security')}>Security and account access</li>
          <li onClick={() => setActiveSection('privacy')}>Privacy and safety</li>
          <li onClick={() => setActiveSection('notifications')}>Notifications</li>
          <li onClick={() => setActiveSection('accessibility')}>Accessibility, display, and languages</li>
          <li onClick={() => setActiveSection('resources')}>Additional resources</li>
          <li onClick={() => setActiveSection('help')}>Help Center</li>
        </ul>
      </div>
      <div className="settings-content">
        {renderSection()}
      </div>
    </div>
  );
};

export default Settings;
