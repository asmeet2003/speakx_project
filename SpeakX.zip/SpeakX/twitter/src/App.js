import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Settings from './pages/Settings';
import Security from './pages/Security';
import Privacy from './pages/Privacy';
import AddTweet from './pages/AddTweet';
import './App.css';
import LeftSidebar from './components/LeftSidebar';

const App = () => {
  return (
    <Router>
      <div className="app-container">
        <Navbar />
        <LeftSidebar />
        <div className="main-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/home" element={<Home />} />
            <Route path="/add-tweet" element={<AddTweet />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/security" element={<Security />} />
            <Route path="/privacy" element={<Privacy />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
};

export default App;
